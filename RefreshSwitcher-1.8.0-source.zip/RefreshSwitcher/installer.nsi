; RefreshSwitcher, Copyright (C) 2026 SmokingTux
; SPDX-License-Identifier: GPL-3.0-or-later
; RefreshSwitcher Setup, Herausgeber SmokingTux
; Build: makensis installer.nsi

Unicode true
ManifestDPIAware true
SetCompressor /SOLID lzma
RequestExecutionLevel admin

!define APP        "RefreshSwitcher"
!define VERSION    "1.8.0"
!define PUBLISHER  "SmokingTux"
!define EXE        "RefreshSwitcher.exe"
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APP}"
!define RUN_KEY    "Software\Microsoft\Windows\CurrentVersion\Run"

Name "${APP}"
OutFile "${APP}-Setup-${VERSION}.exe"
InstallDir "$PROGRAMFILES64\${APP}"
BrandingText "${PUBLISHER}"

!include "MUI2.nsh"
!include "FileFunc.nsh"
!include "x64.nsh"

; ---------- Optik

!define MUI_ICON   "app.ico"
!define MUI_UNICON "app.ico"
!define MUI_HEADERIMAGE
!define MUI_HEADERIMAGE_RIGHT
!define MUI_HEADERIMAGE_BITMAP   "header.bmp"
!define MUI_HEADERIMAGE_UNBITMAP "header.bmp"
!define MUI_WELCOMEFINISHPAGE_BITMAP   "wizard.bmp"
!define MUI_UNWELCOMEFINISHPAGE_BITMAP "wizard.bmp"
!define MUI_ABORTWARNING
!define MUI_COMPONENTSPAGE_NODESC

; ---------- Seiten

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_TEXT "$(RunApp)"
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!insertmacro MUI_PAGE_FINISH

!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

; Englisch zuerst = Standard, sonst wählt das Setup automatisch die Windows-Sprache
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "German"
!insertmacro MUI_LANGUAGE "Spanish"
!insertmacro MUI_LANGUAGE "French"
!insertmacro MUI_LANGUAGE "Ukrainian"

LangString SecApp          ${LANG_ENGLISH} "RefreshSwitcher (required)"
LangString SecApp          ${LANG_GERMAN}  "RefreshSwitcher (erforderlich)"
LangString SecApp          ${LANG_SPANISH}   "RefreshSwitcher (obligatorio)"
LangString SecApp          ${LANG_FRENCH}    "RefreshSwitcher (requis)"
LangString SecApp          ${LANG_UKRAINIAN} "RefreshSwitcher (обов’язково)"
LangString SecStart        ${LANG_ENGLISH} "Start menu shortcut"
LangString SecStart        ${LANG_GERMAN}  "Startmenü-Verknüpfung"
LangString SecStart        ${LANG_SPANISH}   "Acceso directo en el menú Inicio"
LangString SecStart        ${LANG_FRENCH}    "Raccourci dans le menu Démarrer"
LangString SecStart        ${LANG_UKRAINIAN} "Ярлик у меню «Пуск»"
LangString SecDesktop      ${LANG_ENGLISH} "Desktop shortcut"
LangString SecDesktop      ${LANG_GERMAN}  "Desktop-Verknüpfung"
LangString SecDesktop      ${LANG_SPANISH}   "Acceso directo en el escritorio"
LangString SecDesktop      ${LANG_FRENCH}    "Raccourci sur le bureau"
LangString SecDesktop      ${LANG_UKRAINIAN} "Ярлик на робочому столі"
LangString SecAutostart    ${LANG_ENGLISH} "Start with Windows"
LangString SecAutostart    ${LANG_GERMAN}  "Mit Windows starten"
LangString SecAutostart    ${LANG_SPANISH}   "Iniciar con Windows"
LangString SecAutostart    ${LANG_FRENCH}    "Démarrer avec Windows"
LangString SecAutostart    ${LANG_UKRAINIAN} "Запускати разом із Windows"
LangString RunApp          ${LANG_ENGLISH} "Launch RefreshSwitcher"
LangString RunApp          ${LANG_GERMAN}  "RefreshSwitcher starten"
LangString RunApp          ${LANG_SPANISH}   "Iniciar RefreshSwitcher"
LangString RunApp          ${LANG_FRENCH}    "Lancer RefreshSwitcher"
LangString RunApp          ${LANG_UKRAINIAN} "Запустити RefreshSwitcher"
LangString NeedNet         ${LANG_ENGLISH} "RefreshSwitcher needs .NET Framework 4.5 or newer, which was not found.$\r$\nInstall it from microsoft.com and run setup again."
LangString NeedNet         ${LANG_GERMAN}  "RefreshSwitcher braucht .NET Framework 4.5 oder neuer, das nicht gefunden wurde.$\r$\nInstalliere es von microsoft.com und starte das Setup erneut."
LangString NeedNet         ${LANG_SPANISH}   "RefreshSwitcher necesita .NET Framework 4.5 o posterior, que no se encontró.$\r$\nInstálalo desde microsoft.com y vuelve a ejecutar el instalador."
LangString NeedNet         ${LANG_FRENCH}    "RefreshSwitcher nécessite .NET Framework 4.5 ou plus récent, introuvable.$\r$\nInstallez-le depuis microsoft.com puis relancez l’installation."
LangString NeedNet         ${LANG_UKRAINIAN} "RefreshSwitcher потребує .NET Framework 4.5 або новішої версії, яку не знайдено.$\r$\nВстановіть її з microsoft.com і запустіть інсталятор знову."
LangString RemoveSettings  ${LANG_ENGLISH} "Also delete your RefreshSwitcher settings and log?"
LangString RemoveSettings  ${LANG_GERMAN}  "Auch deine RefreshSwitcher-Einstellungen und das Protokoll löschen?"
LangString RemoveSettings  ${LANG_SPANISH}   "¿Eliminar también la configuración y el registro de RefreshSwitcher?"
LangString RemoveSettings  ${LANG_FRENCH}    "Supprimer aussi les paramètres et le journal de RefreshSwitcher ?"
LangString RemoveSettings  ${LANG_UKRAINIAN} "Також видалити налаштування та журнал RefreshSwitcher?"

; ---------- Versionsinfo der Setup-Datei

VIProductVersion "${VERSION}.0"
VIAddVersionKey /LANG=${LANG_ENGLISH} "ProductName"     "${APP}"
VIAddVersionKey /LANG=${LANG_ENGLISH} "CompanyName"     "${PUBLISHER}"
VIAddVersionKey /LANG=${LANG_ENGLISH} "LegalCopyright"  "© 2026 ${PUBLISHER}"
VIAddVersionKey /LANG=${LANG_ENGLISH} "FileDescription" "${APP} Setup"
VIAddVersionKey /LANG=${LANG_ENGLISH} "FileVersion"     "${VERSION}"
VIAddVersionKey /LANG=${LANG_ENGLISH} "ProductVersion"  "${VERSION}"

; ---------- Laufende App beenden (setzt dabei die Spiel-Rate zurück)

!macro StopApp
  IfFileExists "$INSTDIR\${EXE}" 0 +3
    ExecWait '"$INSTDIR\${EXE}" --exit'
    Sleep 1500
  nsExec::Exec 'taskkill /F /IM ${EXE}'
  Pop $0
!macroend

Function .onInit
  SetRegView 64
  ; Bisheriger Installationsort (z. B. Program Files\SmokingTux\RefreshSwitcher) für die Migration
  ReadRegStr $R9 HKLM "${UNINST_KEY}" "InstallLocation"
  ; .NET Framework 4.5+ prüfen (Release >= 378389)
  ReadRegDWORD $0 HKLM "SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" "Release"
  IntCmp $0 378389 net_ok 0 net_ok
    MessageBox MB_OK|MB_ICONSTOP "$(NeedNet)" /SD IDOK
    Abort
  net_ok:
FunctionEnd

; App ohne Adminrechte starten (über Explorer), damit sie nicht erhöht läuft
Function LaunchApp
  Exec '"$WINDIR\explorer.exe" "$INSTDIR\${EXE}"'
FunctionEnd

; ---------- Installation

Section "!$(SecApp)" SecApp
  SectionIn RO

  ; App am alten Ort sauber beenden
  StrCmp $R9 "" +4
  IfFileExists "$R9\${EXE}" 0 +3
    ExecWait '"$R9\${EXE}" --exit'
    Sleep 1500
  !insertmacro StopApp

  ; Alte Installation an anderem Ort entfernen
  StrCmp $R9 "" migrate_done
  StrCmp $R9 "$INSTDIR" migrate_done
    Delete "$R9\${EXE}"
    Delete "$R9\uninstall.exe"
    RMDir "$R9"
    RMDir "$PROGRAMFILES64\${PUBLISHER}"
  migrate_done:

  SetOutPath "$INSTDIR"
  File "${EXE}"
  WriteUninstaller "$INSTDIR\uninstall.exe"

  ; Eintrag in "Apps & Features"
  SetRegView 64
  WriteRegStr   HKLM "${UNINST_KEY}" "DisplayName"          "${APP}"
  WriteRegStr   HKLM "${UNINST_KEY}" "DisplayVersion"       "${VERSION}"
  WriteRegStr   HKLM "${UNINST_KEY}" "Publisher"            "${PUBLISHER}"
  WriteRegStr   HKLM "${UNINST_KEY}" "DisplayIcon"          '"$INSTDIR\${EXE}"'
  WriteRegStr   HKLM "${UNINST_KEY}" "InstallLocation"      "$INSTDIR"
  WriteRegStr   HKLM "${UNINST_KEY}" "UninstallString"      '"$INSTDIR\uninstall.exe"'
  WriteRegStr   HKLM "${UNINST_KEY}" "QuietUninstallString" '"$INSTDIR\uninstall.exe" /S'
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKLM "${UNINST_KEY}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  IntFmt $0 "0x%08X" $0
  WriteRegDWORD HKLM "${UNINST_KEY}" "EstimatedSize" "$0"

  ; Bestehenden Autostart-Eintrag (z. B. aus Downloads) auf den neuen Pfad umbiegen
  ReadRegStr $0 HKCU "${RUN_KEY}" "${APP}"
  StrCmp $0 "" +2
    WriteRegStr HKCU "${RUN_KEY}" "${APP}" '"$INSTDIR\${EXE}"'
SectionEnd

Section "$(SecStart)" SecStart
  SetShellVarContext all
  CreateShortcut "$SMPROGRAMS\${APP}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\${EXE}" 0
SectionEnd

Section /o "$(SecDesktop)" SecDesktop
  SetShellVarContext all
  CreateShortcut "$DESKTOP\${APP}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\${EXE}" 0
SectionEnd

Section "$(SecAutostart)" SecAutostart
  WriteRegStr HKCU "${RUN_KEY}" "${APP}" '"$INSTDIR\${EXE}"'
SectionEnd

; ---------- Deinstallation

Function un.onInit
  SetRegView 64
FunctionEnd

Section "Uninstall"
  !insertmacro StopApp

  SetShellVarContext all
  Delete "$SMPROGRAMS\${APP}.lnk"
  Delete "$DESKTOP\${APP}.lnk"

  DeleteRegValue HKCU "${RUN_KEY}" "${APP}"

  Delete "$INSTDIR\${EXE}"
  Delete "$INSTDIR\uninstall.exe"
  RMDir "$INSTDIR"

  SetRegView 64
  DeleteRegKey HKLM "${UNINST_KEY}"

  SetShellVarContext current
  MessageBox MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2 "$(RemoveSettings)" /SD IDNO IDNO +2
    RMDir /r "$APPDATA\${APP}"
SectionEnd
