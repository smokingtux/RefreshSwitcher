// RefreshSwitcher, Copyright (C) 2026 SmokingTux
// SPDX-License-Identifier: GPL-3.0-or-later
// This program is free software under the GNU General Public License v3.0 or later. See LICENSE.
// Tests für die Logik ohne Windows-Abhängigkeit.
// Build: mcs -langversion:5 -sdk:4.5 -r:System.Windows.Forms.dll -r:System.Drawing.dll -r:System.Core.dll -main:RefreshSwitcher.Tests -out:Tests.exe RefreshSwitcher.cs Tests.cs
using System;
using System.Collections.Generic;
using System.Linq;

namespace RefreshSwitcher
{
    static class Tests
    {
        static int passed, failed;

        static void Check(string name, bool ok)
        {
            if (ok) passed++; else failed++;
            Console.WriteLine((ok ? "  ok    " : "  FAIL  ") + name);
        }

        static MonitorInfo Mon(string key, int w, int h, params int[] rates)
        {
            return new MonitorInfo { Key = key, GdiName = key, FriendlyName = key, Width = w, Height = h, Rates = rates };
        }

        static int Main()
        {
            var t0 = new DateTime(2026, 10, 21, 12, 0, 0);

            Console.WriteLine("RateLogic");
            int[] aw = { 24, 25, 30, 48, 50, 59, 60, 100, 119, 120, 144, 165, 240 };
            Check("Desktop-Standard 60 Hz", RateLogic.DefaultIdle(aw) == 60);
            Check("Ohne 60 Hz: nächsthöhere Rate", RateLogic.DefaultIdle(new[] { 48, 75, 144 }) == 75);
            Check("Nur niedrige Raten: höchste", RateLogic.DefaultIdle(new[] { 24, 30, 50 }) == 50);
            Check("Gespeicherte Rate wird auf verfügbare gerundet", RateLogic.ResolveMax(new[] { 60, 120, 144 }, 165) == 144);
            Check("Ohne gespeicherte Rate: Maximum", RateLogic.ResolveMax(aw, null) == 240);
            Check("Gleichstand rundet nach oben", RateLogic.Nearest(new[] { 100, 120 }, 110) == 120);
            Check("Leere Rate-Liste liefert 0", RateLogic.ResolveIdle(new int[0], null) == 0);

            var a = new List<MonitorInfo> { Mon("A", 3840, 2160, 60, 120, 240) };
            Check("Gleiches Layout erkannt", RateLogic.SameLayout(a, new List<MonitorInfo> { Mon("A", 3840, 2160, 60, 120, 240) }));
            Check("Höhenänderung erkannt", !RateLogic.SameLayout(a, new List<MonitorInfo> { Mon("A", 3840, 1600, 60, 120, 240) }));
            Check("Geänderte Raten erkannt", !RateLogic.SameLayout(a, new List<MonitorInfo> { Mon("A", 3840, 2160, 60, 120) }));
            Check("Monitorwechsel erkannt", !RateLogic.SameLayout(a, new List<MonitorInfo> { Mon("B", 3840, 2160, 60, 120, 240) }));

            Console.WriteLine("SwitchPolicy");
            var p = new SwitchPolicy { IdleDelaySec = 6, StabilitySec = 3 };
            Check("Start ohne Spiel: Desktop", p.Update(t0, null, null) == Target.Idle);
            Check("Spiel aus Liste schaltet sofort", p.Update(t0.AddSeconds(2), "RocketLeague", null) == Target.Max && p.ActiveReason == Reason.GameList);
            Check("Nach Spielende zunächst noch Spiel", p.Update(t0.AddSeconds(4), null, null) == Target.Max);
            Check("Nach Verzögerung zurück auf Desktop", p.Update(t0.AddSeconds(8.1), null, null) == Target.Idle && p.ActiveGame == null);

            p = new SwitchPolicy { IdleDelaySec = 6, StabilitySec = 3 };
            p.Update(t0, null, null);
            Check("Vollbild: erst Kandidat", p.Update(t0.AddSeconds(1), null, "video") == Target.Idle && p.PendingCandidate == "video");
            Check("Vollbild: nach Stabilitätszeit Spiel", p.Update(t0.AddSeconds(4), null, "video") == Target.Max && p.ActiveReason == Reason.Fullscreen);
            p = new SwitchPolicy { IdleDelaySec = 6, StabilitySec = 3 };
            p.Update(t0, null, null);
            p.Update(t0.AddSeconds(1), null, "a");
            Check("Kurzer Vordergrund löst nichts aus", p.Update(t0.AddSeconds(2), null, null) == Target.Idle && p.PendingCandidate == null);
            p.Update(t0.AddSeconds(3), null, "a");
            Check("Kandidat-Wechsel startet Zeit neu", p.Update(t0.AddSeconds(5), null, "b") == Target.Idle);
            Check("Liste hat Vorrang vor Vollbild-Wartezeit", p.Update(t0.AddSeconds(5.5), "game", "b") == Target.Max && p.ActiveReason == Reason.GameList);

            p = new SwitchPolicy { IdleDelaySec = 6, StabilitySec = 0 };
            p.Update(t0, null, "chrome");
            p.Forget("chrome");
            Check("Ignorieren setzt Spielzeit zurück", p.Update(t0.AddSeconds(1), null, null) == Target.Idle);

            p = new SwitchPolicy { Mode = SwitchMode.Max };
            Check("Fester Spielmodus", p.Update(t0, null, null) == Target.Max && p.ActiveGame == null);
            p.Mode = SwitchMode.Idle;
            Check("Fester Desktopmodus ignoriert Spiele", p.Update(t0, "RocketLeague", null) == Target.Idle);

            Console.WriteLine("Akkumodus");
            p = new SwitchPolicy { IdleDelaySec = 6, StabilitySec = 3 };
            Check("Akku: Akku-Ziel", p.Update(t0, null, null, true) == Target.Battery);
            Check("Akku hat Vorrang vor Spiel", p.Update(t0.AddSeconds(2), "RocketLeague", null, true) == Target.Battery && p.ActiveGame == null);
            Check("Netzteil mit Spiel: sofort Spiel", p.Update(t0.AddSeconds(4), "RocketLeague", null, false) == Target.Max);
            Check("Wieder Akku: sofort Akku", p.Update(t0.AddSeconds(5), "RocketLeague", null, true) == Target.Battery);
            Check("Netzteil ohne Spiel: sofort Desktop", p.Update(t0.AddSeconds(6), null, null, false) == Target.Idle);
            p.Mode = SwitchMode.Max;
            Check("Fester Spielmodus schlägt Akku", p.Update(t0.AddSeconds(7), null, null, true) == Target.Max);

            Console.WriteLine("Spielebibliotheken");
            string vdf = "\"libraryfolders\"\n{\n\t\"0\"\n\t{\n\t\t\"path\"\t\t\"C:\\\\Program Files (x86)\\\\Steam\"\n\t}\n\t\"1\"\n\t{\n\t\t\"path\"\t\t\"D:\\\\SteamLibrary\"\n\t}\n}";
            var libs = LibraryLogic.ParseSteamLibraryFolders(vdf);
            Check("Steam-Bibliotheken gelesen", libs.SequenceEqual(new[] { "C:\\Program Files (x86)\\Steam", "D:\\SteamLibrary" }));
            Check("Epic-Installationsort gelesen", LibraryLogic.ParseEpicInstallLocation("{ \"DisplayName\": \"Fortnite\", \"InstallLocation\": \"E:\\\\Epic Games\\\\Fortnite\" }") == "E:\\Epic Games\\Fortnite");
            var roots = new[] { LibraryLogic.NormalizeRoot("D:\\SteamLibrary\\steamapps\\common") };
            Check("Spiel im Bibliotheksordner erkannt", LibraryLogic.IsUnder("d:\\steamlibrary\\steamapps\\common\\Rocket League\\RocketLeague.exe", roots));
            Check("Ähnlicher Ordnername zählt nicht", !LibraryLogic.IsUnder("D:\\SteamLibrary\\steamapps\\common2\\x.exe", roots));
            Check("Absturzmelder ausgefiltert", LibraryLogic.IsHelper("UnityCrashHandler64", "D:\\Lib\\Game\\UnityCrashHandler64.exe"));
            Check("Anti-Cheat ausgefiltert", LibraryLogic.IsHelper("EasyAntiCheat_EOS", "D:\\Lib\\Game\\EasyAntiCheat\\x.exe"));
            Check("Wallpaper Engine ausgefiltert", LibraryLogic.IsHelper("wallpaper64", "D:\\SteamLibrary\\steamapps\\common\\wallpaper_engine\\wallpaper64.exe"));
            Check("Echtes Spiel bleibt", !LibraryLogic.IsHelper("RocketLeague", "D:\\SteamLibrary\\steamapps\\common\\rocketleague\\Binaries\\Win64\\RocketLeague.exe"));
            var lp = new SwitchPolicy { IdleDelaySec = 6, StabilitySec = 3 };
            Check("Bibliotheksspiel schaltet sofort", lp.Update(t0, "eldenring", null, false, Reason.Library) == Target.Max && lp.ActiveReason == Reason.Library);
            Check("Bibliotheks-Erkennung standardmäßig an", new Settings().DetectLibraries);

            Console.WriteLine("RetryState");
            var r = new RetryState();
            Check("Erster Versuch nötig", r.ShouldApply(Target.Max, t0));
            Check("Kein Versuch ohne Ziel", !r.ShouldApply(Target.None, t0));
            r.Record(Target.Max, false, t0);
            Check("Fehler: nicht sofort erneut", !r.ShouldApply(Target.Max, t0.AddSeconds(1)));
            Check("Fehler: nach 5 s erneut", r.ShouldApply(Target.Max, t0.AddSeconds(5)));
            r.Record(Target.Max, false, t0.AddSeconds(5));
            r.Record(Target.Max, false, t0.AddSeconds(20));
            r.Record(Target.Max, false, t0.AddSeconds(50));
            Check("Nach 4 Fehlversuchen gestoppt", r.GaveUp && !r.ShouldApply(Target.Max, t0.AddHours(1)));
            Check("Neues Ziel versucht wieder", r.ShouldApply(Target.Idle, t0.AddHours(1)));
            r.Record(Target.Idle, true, t0.AddHours(1));
            Check("Erfolg: kein erneuter Versuch", !r.ShouldApply(Target.Idle, t0.AddHours(2)) && r.Attempts == 1);
            r.Reset();
            Check("Reset erzwingt Versuch", r.ShouldApply(Target.Idle, t0.AddHours(2)));

            Console.WriteLine("Settings");
            var s = Settings.ParseLines(new[]
            {
                "mode=Max", "games=RocketLeague.exe;C:\\Games\\bf6.exe;a<b;rocketleague", "delay=9999", "fsdelay=5", "poll=0",
                "lang=De", "battery=1", "battery.\\\\?\\DISPLAY#X=48", "battery.\\\\?\\DISPLAY#Z=2000", "idle.\\\\?\\DISPLAY#X=60", "max.\\\\?\\DISPLAY#X=abc", "exclude.\\\\?\\DISPLAY#Y=1", "mode=7", "unknown=1", "kaputt"
            });
            Check("Modus gelesen, ungültiger Modus ignoriert", s.Mode == SwitchMode.Max);
            Check("Spielnamen bereinigt und dedupliziert", s.Games.SequenceEqual(new[] { "RocketLeague", "bf6" }));
            Check("Verzögerung außerhalb Bereich ignoriert", s.IdleDelay == 6);
            Check("Vollbild-Verzögerung gelesen", s.FullscreenDelay == 5);
            Check("Ungültiges Prüfintervall ignoriert", s.PollSeconds == 2);
            Check("Sprache gelesen", s.Language == Lang.De);
            Check("Gültige Rate gelesen, ungültige ignoriert", s.IdleHz.Count == 1 && s.MaxHz.Count == 0);
            Check("Akkumodus und gültige Akku-Rate gelesen", s.BatteryMode && s.BatteryHz.Count == 1 && s.BatteryHz["\\\\?\\DISPLAY#X"] == 48);
            Check("Monitor-Ausnahme gelesen", s.ExcludedMonitors.Contains("\\\\?\\DISPLAY#Y"));
            Check("Veraltete Profile gefunden", s.StaleProfiles(new[] { "\\\\?\\DISPLAY#X" }).SequenceEqual(new[] { "\\\\?\\DISPLAY#Y" }));
            s.RemoveProfiles(s.StaleProfiles(new string[0]));
            Check("Profile entfernt", s.IdleHz.Count == 0 && s.BatteryHz.Count == 0 && s.ExcludedMonitors.Count == 0);

            Console.WriteLine("Sprachen");
            var langs = (Lang[])Enum.GetValues(typeof(Lang));
            Check("5 Sprachen", langs.Length == 5);
            Check("Jeder Text in allen Sprachen", L.Keys.All(k => L.Count(k) == langs.Length));
            bool formatOk = true;
            foreach (var lang in langs)
            {
                L.Current = lang;
                foreach (var k in L.Keys)
                {
                    try { string.Format(L.T(k), t0, "x", "y", "z"); }
                    catch { formatOk = false; Console.WriteLine("    Formatfehler " + lang + " " + k); }
                }
            }
            L.Current = Lang.En;
            Check("Alle Texte formatierbar", formatOk);
            Check("Ukrainisch aus Einstellungen", Settings.ParseLines(new[] { "lang=Uk" }).Language == Lang.Uk);
            Check("Unbekannte Sprache ignoriert", Settings.ParseLines(new[] { "lang=9" }).Language == Lang.En);

            Console.WriteLine("Themes");
            foreach (ThemeId id in Enum.GetValues(typeof(ThemeId)))
            {
                var pal = Palette.Get(id);
                Check(id + ": Text gut lesbar (>= 7:1)", Palette.Contrast(pal.Text, pal.Bg) >= 7 && Palette.Contrast(pal.Text, pal.Surface) >= 7);
                Check(id + ": Nebentext lesbar (>= 4.5:1)", Palette.Contrast(pal.Muted, pal.Bg) >= 4.5);
                Check(id + ": Fehlertext lesbar (>= 4.5:1)", Palette.Contrast(pal.Error, pal.Bg) >= 4.5);
                Check(id + ": Zustandsfarben erkennbar (>= 3:1)",
                    Palette.Contrast(pal.Idle, pal.Bg) >= 3 && Palette.Contrast(pal.Game, pal.Bg) >= 3 && Palette.Contrast(pal.Battery, pal.Bg) >= 3);
                Check(id + ": Flächen unterscheidbar", pal.Surface != pal.Bg && pal.SurfaceHi != pal.Surface);
            }
            Check("Theme aus Einstellungen", Settings.ParseLines(new[] { "theme=Oled" }).Theme == ThemeId.Oled);
            Check("Unbekanntes Theme ignoriert", Settings.ParseLines(new[] { "theme=Rainbow" }).Theme == ThemeId.Oled);
            Check("Alte Theme-Namen übernommen", Settings.ParseLines(new[] { "theme=Midnight" }).Theme == ThemeId.Ocean
                && Settings.ParseLines(new[] { "theme=Plum" }).Theme == ThemeId.Graphite && Settings.ParseLines(new[] { "theme=Neon" }).Theme == ThemeId.Graphite
                && Settings.ParseLines(new[] { "theme=Graphite" }).Theme == ThemeId.Graphite);

            Console.WriteLine();
            Console.WriteLine(passed + " bestanden, " + failed + " fehlgeschlagen");
            return failed == 0 ? 0 : 1;
        }
    }
}
